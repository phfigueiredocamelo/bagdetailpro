/**
 * @package   akeebabackup
 * @copyright Copyright (c)2006-2022 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

-- Ensure the correct character set and collation for all tables and columns
-- Note: this update was made obsolete by the 9.0.10 update. Therefore its contents are removed to prevent Joomla from
-- tripping over its feet...